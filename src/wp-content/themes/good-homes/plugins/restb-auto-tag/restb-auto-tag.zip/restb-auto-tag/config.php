<?php

// Constants that configure the behaviour of the plugin
if ( ! defined( "AUTO_REGISTER_KEY" ) )
    define("AUTO_REGISTER_KEY", true);

if ( ! defined( "CAN_UPGRADE_KEY" ) )
    define("CAN_UPGRADE_KEY", true);

if ( ! defined( "DISPLAY_DEV_OPTIONS" ) )
    define("DISPLAY_DEV_OPTIONS", true);


// Conditional constants
if ( ! defined( "UPGRADED_MAX_MONTHLY_REQUESTS" ) )
    define("UPGRADED_MAX_MONTHLY_REQUESTS", 2000);

if ( ! defined( "REDUCED_IMAGE_SIZE" ) )
    define("REDUCED_IMAGE_SIZE", 500);
