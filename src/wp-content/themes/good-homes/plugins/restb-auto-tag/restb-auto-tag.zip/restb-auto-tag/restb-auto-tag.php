<?php
/*
Plugin Name: Restb.ai Auto Tag
Plugin URI: http://www.restb.ai
Description: Automatically extract the information of Real Estate pictures!
Version: 1.0
Author: Restb.ai
Author URI: http://www.restb.ai
*/

require_once( dirname( __FILE__ ) . '/config.php' );

// Constants that should not change often
define("RESTB_OPTIONS", "REautotag_options");
define("OPTION_CLIENT_KEY", "client_key");
define("OPTION_IS_KEY_INITIALIZED", "is_key_initialized");
define("OPTION_IS_KEY_UPGRADED", "is_key_upgraded");
define("OPTION_API_ERRORS", "api_errors");
define("OPTION_HANDLED_POSTS", "handled_post_ids");
define("OPTION_WELCOME_DISPLAYED", "welcome_displayed");
define("HANDLED_POSTS_DELIMITER", ":;");

// Server constants
define("URL_UPGRADE_KEY", "http://restb.ai/extensions/upgrade-account-settings");
define("URL_KEY_SERVER", "https://ks.restb.ai/v1");
define("URL_REGISTER_KEY", URL_KEY_SERVER . "/register");
define("URL_CLIENT_INFO", URL_KEY_SERVER . "/client_info");

// Actions and filters
register_activation_hook( __FILE__, 'RE_activation_hook' );
add_action( 'plugins_loaded', 'set_up_client_key' );
add_action( 'admin_menu', 'REautotag_add_options_page' );
add_action('admin_init', 'REautotag_init' );
add_action( 'add_attachment', 'REautotag_update_media_info' );
add_action( 'admin_notices', 'REautotag_dashboard_notice' );

// Necessary because GUID is not changed and wp_update_attachment_metadata
// function deletes our generated metadata.
add_filter( 'wp_update_attachment_metadata', 'prevent_metadata_deletion', 10, 2);

function RE_activation_hook() {
	register_uninstall_hook( __FILE__, 'RE_uninstall_hook' );
	REautotag_add_defaults();
}

function RE_uninstall_hook() {
	delete_option( RESTB_OPTIONS );
}

function prevent_metadata_deletion($data, $attachment_id) {
	if (is_restb_handled_post($attachment_id)) {
		if (empty($data)) {
			$data = wp_get_attachment_metadata($attachment_id);
			remove_all_handled();
		}
	}

	return $data;
}

function is_restb_handled_post($post_id) {
	$handled_post_ids = get_restb_option(OPTION_HANDLED_POSTS);
	$arr = explode(HANDLED_POSTS_DELIMITER, $handled_post_ids);
	return in_array($post_id, $arr);
}

function save_handled_post_id($post_id) {
	$handled_post_ids = get_restb_option(OPTION_HANDLED_POSTS);
	$delimiter = empty($handled_post_ids) ? '' : HANDLED_POSTS_DELIMITER;
	$handled_post_ids .= $delimiter . $post_id;
	return update_restb_option(OPTION_HANDLED_POSTS, $handled_post_ids);
}

function remove_all_handled() {
	return update_restb_option(OPTION_HANDLED_POSTS, "");
}

function get_restb_option($option, $default = false) {
	$restb_options = get_option(RESTB_OPTIONS);

	if (array_key_exists($option, $restb_options)) {
		return $restb_options[$option];
	} else {
		return $default;
	}
}

function update_restb_option($option, $new_value) {
	$restb_options = get_option(RESTB_OPTIONS);
	$restb_options[$option] = $new_value;
	return update_option(RESTB_OPTIONS, $restb_options);
}

function set_up_client_key() {
	if (has_to_set_up_key())
		ask_for_client_key();

	if (can_upgrade_key())
		set_if_upgraded_key();
}

function has_to_set_up_key() {
	$is_key_initialized = get_restb_option(OPTION_IS_KEY_INITIALIZED);
	$client_key = get_restb_option(OPTION_CLIENT_KEY);

	return AUTO_REGISTER_KEY && empty($client_key) && empty($is_key_initialized);
}

function ask_for_client_key() {
	$data = client_key_request_data();
	$response = CallAPI('GET', URL_REGISTER_KEY, $data);

	if (isset($response->client_key)) {
		save_client_key($response->client_key);
	} else {
		display_error($response->code, $response->message);
	}
}

function save_client_key($key) {
	update_restb_option(OPTION_IS_KEY_INITIALIZED, 1);
	update_restb_option(OPTION_CLIENT_KEY, $key);
	set_if_upgraded_key();
}

function set_if_upgraded_key() {
	$data = client_info_request_data();
	$response = CallAPI('GET', URL_CLIENT_INFO, $data);

	if (isset($response->max_monthly_requests)) {
		save_if_upgraded_key($response->max_monthly_requests);
	} else {
		add_restb_error($response->code, $response->message);
	}
}

function remove_client_key() {
	update_restb_option(OPTION_IS_KEY_INITIALIZED, 0);
	update_restb_option(OPTION_IS_KEY_UPGRADED, 0);
	update_restb_option(OPTION_CLIENT_KEY, "");
}

function client_info_request_data() {
	$client_key = get_client_key();

	return array(
		"client_key" => $client_key
	);
}

function save_if_upgraded_key($max_monthly_requests) {
	if ($max_monthly_requests >= UPGRADED_MAX_MONTHLY_REQUESTS)
		update_restb_option(OPTION_IS_KEY_UPGRADED, 1);
}

function can_upgrade_key() {
	return CAN_UPGRADE_KEY && !is_key_upgraded() && !is_client_key_empty();
}

function is_key_upgraded() {
	return (boolean) get_restb_option(OPTION_IS_KEY_UPGRADED);
}

function display_error($code, $message) {
	switch ( $code ) {
		case "004_upgradable": // Request Limit Reached
			display_upgrade_notice();
			break;
		default:
			display_notice('error', "restb-auto-tag ($code): $message");
			break;
	}
}

function client_key_request_data() {
	$current_user = wp_get_current_user();
	$site_url = get_site_url();

	return array(
		"cType" => "wordpress",
		"cID" => $site_url,
		"cIDType" => "siteurl"
	);
}

function REautotag_dashboard_notice() {
	display_welcome_once();
	client_key_notice();
	errors_notice_and_destroy();
}

function display_welcome_once() {
	if (has_to_display_welcome())
		display_welcome();

	update_restb_option(OPTION_WELCOME_DISPLAYED, "done");
}

function has_to_display_welcome() {
	return empty(get_restb_option(OPTION_WELCOME_DISPLAYED));
}

function display_welcome() {
	?>
	<div class="notice notice-success is-dismissible">
		<div style="float: left;">
			<img  alt="alt" style="width: 120px;"
			src="https://media.licdn.com/mpr/mpr/shrink_200_200/AAEAAQAAAAAAAAyQAAAAJDA4ZDIwMGFjLWQ3NTYtNDVhOC04MTFkLTljYmVlNTU1MGFmOQ.png">
    	</div>
		<div class="content">
			<h3>Real Estate Auto Tag<small> by <a href="http://restb.ai">Restb.ai</a></small></h3>
			<p class="lead">
				This plugin empowers your site's photos with Real Estate oriented AI image recognition. 
				It will automatically populate the "Title", "Alt", "Description" and "Filename" of
				your uploaded photos with AI driven metadata tags. Extend your default <strong>FREE 50 pictures per month</strong>
				by updating your <a href="<?=get_settings_url()?>">settings</a> today!
			</p>
			<?php
				if (can_upgrade_key())
					display_upgrade_button();
			?>
		</div>
		<div style="clear: both;"></div> 
	</div>
    <?php
}

function client_key_notice() {
	if (is_client_key_empty())
		display_notice('warning', 'Restb.ai client key is missing. Please enter your valid client key in the plugin'
		. ' <a href="' . get_settings_url() . '">settings</a> field.'
		. ' If you don\'t have a client key you can register for one by contacting us at'
		. ' <a href="mailto:dominik@restb.ai?Subject=Free%20Restb.ai%20Auto-Tag%20plugin%20key" target="_top">dominik@restb.ai</a>');
}

function errors_notice_and_destroy() {
	$restb_errors = get_restb_option(OPTION_API_ERRORS);

	if (is_array($restb_errors))
		foreach ($restb_errors as $key => $value)
			display_error($key, $value);

	update_restb_option(OPTION_API_ERRORS, []);
}

function display_notice($notice_type, $message) {
	?>
	    <div class="notice notice-<?=$notice_type?> is-dismissible">
	        <p><?php _e( $message, 'restb-auto-tag' ); ?></p>
	    </div>
    <?php
}

/* Define default settings. */
function REautotag_add_defaults() {
	$tmp = get_option( 'REautotag_options' );
	if ( has_to_reset_default_options($tmp) ) {
		delete_option( 'REautotag_options' );
		$arr = array(
			"client_key"          => "",
			OPTION_HANDLED_POSTS  => "",
			"text_filename"       => "",
			"text_title"          => "{{HomeScenes}} {{FeaturesConnector}} {{HomeFeatures}}",
			"text_alt"            => "{{HomeScenes}} {{FeaturesConnector}} {{HomeFeatures}}",
			"text_description"    => "{{HomeScenes}} {{FeaturesConnector}} {{HomeFeatures}}",
			"text_caption"        => "{{HomeScenes}} {{FeaturesConnector}} {{HomeFeatures}}",
			"features_connector"  => "with",
			"and_conjunction"     => "and"
		);
		update_option( 'REautotag_options', $arr );
	}
}

function has_to_reset_default_options( $options ) {
	if ( !is_array( $options )) return true;

	if ( array_key_exists( 'chk_default_options_db', $options ) )
		if ( $options['chk_default_options_db'] == '1' )
			return true;
	
	return false;
}

/* Init plugin options. */
function REautotag_init(){
    register_setting( 'REautotag_plugin_options', 'REautotag_options' );
}

/* Add menu page. */
function REautotag_add_options_page() {
	add_menu_page( 'Restb.ai Auto Tag Menu Page', 'Restb.ai Autotag', 'manage_options', __FILE__,
		'REautotag_render_form', plugins_url( 'images/restb_logo.png', __FILE__ ) );
}

/* Render Plugin options page. */
function REautotag_render_form() {
	?>
	<div class="wrap">
		<h2><?php _e( 'Restb.ai Auto Tag', 'restb-auto-tag' ); ?></h2>

		<form method="post" action="options.php">
			<?php settings_fields( 'REautotag_plugin_options' ); ?>
			<?php $options = get_option( 'REautotag_options' ); ?>
			<input name="REautotag_options[<?=OPTION_HANDLED_POSTS?>]" type="hidden" value="<?=$options[OPTION_HANDLED_POSTS]?>"/>
			<input name="REautotag_options[<?=OPTION_IS_KEY_INITIALIZED?>]" type="hidden" value="<?=$options[OPTION_IS_KEY_INITIALIZED]?>"/>
			<input name="REautotag_options[<?=OPTION_WELCOME_DISPLAYED?>]" type="hidden" value="<?=$options[OPTION_WELCOME_DISPLAYED]?>"/>

			<table class="form-table">
				<tr valign="top">
					<th scope="row"><?php _e( 'Authorize the Restb.ai Plugin', 'restb-auto-tag' ); ?></th>
					<td>
						<p>Thank you for installing Restb.ai's Auto Tag plugin for wordpress. This field should be auto-populated by the plugin. If you don't have a client key you can register for one by contacting us at <a href="mailto:dominik@restb.ai?Subject=Free%20Restb.ai%20Auto-Tag%20plugin%20key" target="_top">dominik@restb.ai</a></p>
						<label><strong><?php _e( 'Client key', 'restb-auto-tag' ); ?> </strong><input name="REautotag_options[client_key]" type="text" size="100" value="<?=$options[OPTION_CLIENT_KEY]?>"/> </label><br>
						<?php
							if (can_upgrade_key())
								display_upgrade_button();
						?>
					</td>

				</tr>
				<tr valign="top">
					<th scope="row"><?php _e( 'Text replacing options', 'restb-auto-tag' ); ?></th>
					<td>
						<label>
							<?php _e( 'Automatically add image tags to \'Filename\' (Keep it empty if you don\'t want any changes)', 'restb-auto-tag' ); ?>
							<input
								name="REautotag_options[text_filename]" type="text" size="100"
								value="<?=$options['text_filename']?>"/>
						</label><br>
						<label><?php _e( 'Automatically add image tags to \'Title\' (Keep it empty for default Title)', 'restb-auto-tag' ); ?> <input name="REautotag_options[text_title]" type="text" size="100" value="<?=$options['text_title']?>"/> </label><br>
						<label><?php _e( 'Automatically add image tags to \'Alternative Text\' attribute', 'restb-auto-tag' ); ?> <input name="REautotag_options[text_alt]" type="text" size="100" value="<?=$options['text_alt']?>"/> </label><br>
						<label><?php _e( 'Automatically add image tags to \'Caption\' attribute', 'restb-auto-tag' ); ?> <input name="REautotag_options[text_caption]" type="text" size="100" value="<?=$options['text_caption']?>"/> </label><br>
						<label><?php _e( 'Automatically add image tags to \'Description\' attribute', 'restb-auto-tag' ); ?> <input name="REautotag_options[text_description]" type="text" size="100" value="<?=$options['text_description']?>"/> </label><br>
					</td>

				</tr>
				<tr>
					<th scope="row">
						<?php _e('Features connector word', 'restb-auto-tag'); ?>
					</th>
					<td>
						<label>
							<?php _e('Only show this connector word if {{HomeFeatures}} exist', 'restb-auto-tag' ); ?>
							<input name="REautotag_options[features_connector]" type="text" size="100" value="<?=$options['features_connector']?>"/>
						</label>
						<br>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php _e( 'Conjunction word', 'restb-auto-tag' ); ?></th>
					<td>
						<label><?php _e( 'Replace last comma with a connecting conjunction word (e.g. \'And\' or \'&\') ', 'restb-auto-tag' ); ?> <input name="REautotag_options[and_conjunction]" type="text" size="100" value="<?=$options['and_conjunction']?>"/> </label><br>
					</td>
				</tr>
				<?php
					display_dev_options();
				?>
			</table>
			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e( 'Save Changes', 'restb-auto-tag' ); ?>" />
			</p>
		</form>




	</div>
<?php
}
function display_dev_options() {
	if (DISPLAY_DEV_OPTIONS) {
		?>
		<tr valign="top" style="border-top:#dddddd 1px solid;">
			<th scope="row"><?php _e( 'Database Options', 'restb-auto-tag' ); ?></th>
			<td>
				<label>
					<input name="REautotag_options[chk_default_options_db]" type="checkbox" value="1"
					<?php if ( isset( $options['chk_default_options_db'] ) ) {
						checked( '1', $options['chk_default_options_db'] );
					} ?> />
					<?php _e( 'Restore defaults upon plugin deactivation/reactivation', 'restb-auto-tag' ); ?>
				</label>
				<p class="description">
					<?php _e( 'Only check this if you want to reset plugin settings upon Plugin reactivation',
						'restb-auto-tag' ); ?>
				</p>
			</td>
		</tr>
		<?php
	}
}

/* Display the Settings link on Plugins page. */
function REautotag_settings_link( $links ) {
    $url = get_settings_url();
    $settings_link = '<a href="' . $url . '">' . __('Settings', 'textdomain') . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}

function get_settings_url() {
	return get_admin_url() . 'options-general.php?page=restb-auto-tag/restb-auto-tag.php';
}

function display_upgrade_notice() {
	?>
	<div class="notice notice-warning is-dismissible">
		<div style="float: left;">
			<img  alt="alt" style="width: 120px;"
			src="https://media.licdn.com/mpr/mpr/shrink_200_200/AAEAAQAAAAAAAAyQAAAAJDA4ZDIwMGFjLWQ3NTYtNDVhOC04MTFkLTljYmVlNTU1MGFmOQ.png">
    	</div>
		<div class="content">
			<h3>Monthly limit reached</h3>
			<p class="lead">
				Oops! You reached your complimentary Auto-Tag limit for the month.
				Upgrade your account to increase your monthly limit from 50 to 1000 tagged photos.
			</p>
			<?php
				if (can_upgrade_key())
					display_upgrade_button();
			?>
		</div>
		<div style="clear: both;"></div> 
	</div>
    <?php
}

function display_upgrade_button() {
	?>
	<p>
		<a class="button button-primary" target="_blank" href="<?=get_upgrade_url()?>">
			Upgrade account
		</a>
	</p>
    <?php
}

function get_upgrade_url() {
	$params = array(
		"your-apikey" => get_client_key(),
		"utm_source"  => "WP-plugin",
		"utm_medium"  => "cta-upgrade-settings"
	);

	return sprintf("%s?%s", URL_UPGRADE_KEY, http_build_query($params));
}

function REautotag_after_setup_theme() {
     add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'REautotag_settings_link');
}


add_action ('after_setup_theme', 'REautotag_after_setup_theme');

function get_client_key() {
	$options =  get_option(RESTB_OPTIONS);
	return $options[OPTION_CLIENT_KEY];
}

function is_client_key_empty() {
	$key = get_client_key();

	return empty($key);
}

function REautotag_update_media_info( $id ) {

	if (is_client_key_empty())
		return;

	$options     = get_option( 'REautotag_options' );

	$uploaded_post = get_post( $id );
	$title            = $uploaded_post->post_title;

	$image_file = get_reduced_tmp_file( $id );

	$arrHomeScenes = restbapi('classify', 'real_estate_global', $image_file['url']);
	$arrHomeFeatures = restbapi('segmentation', 're_features', $image_file['url']);

	remove_file($image_file['local']);

	if ($arrHomeScenes == NULL) {
		return;
	} else if ($arrHomeScenes->error == "true") {
		handle_restb_errors($arrHomeScenes);
		return;
	}else{
		foreach($arrHomeScenes->response->probabilities as $probabilities)
		{

			if ($probabilities[0][0]=='non_related'){
				return ;
			}else{
				$scene = str_replace("_", " ", $probabilities[0][0]);
				$homescences_reply = $scene;
			}
		    //foreach($probabilities as $homescene)
		    //{
		    	//$homescences_reply .=  $homescene[0];

		    //}
		}
	}

	if ($arrHomeFeatures == NULL) {
		return;
	} else if ($arrHomeFeatures->error == "true") {
		handle_restb_errors($arrHomeFeatures);
		return;
	}else{
		
		$duplicated_features = array();
		$homefeatures_reply  = "";

		foreach($arrHomeFeatures->response->objects as $objects)
		{
			$feature = str_replace("_", " ", $objects[0]);
			if (count($duplicated_features)==0){
				$homefeatures_reply .= $feature.', ';
			}elseif (!in_array($objects[0], $duplicated_features)) {
	    		$homefeatures_reply .= $feature.', ';
	  		}
	  	    $duplicated_features[] = $objects[0];


		}
	}
	//Remove last comma string
	$homefeatures_reply = rtrim($homefeatures_reply, ', ');
	//Replace last comma with And conjuntion
	$andreplacement = ' '.$options['and_conjunction'].'\1';
	$homefeatures_reply = preg_replace('/,([^,]*)$/', $andreplacement, $homefeatures_reply);
	//$restb_reply = $jsonHomeScenes.$jsonHomeFeatures;





	// start updating the post
	$uploaded_post               = array();
	$uploaded_post['ID']         = $id;

	$features_connector = $options['features_connector'];

	// add formatted alt
	if ( isset( $options['text_alt'] ) && $options['text_alt'] ) {
		$altstr = $options['text_alt'];
		$altstr = add_features_connector($altstr, $homefeatures_reply,
			$features_connector);
		$altstr = str_replace("{{HomeScenes}}", $homescences_reply, $altstr);
		$altstr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $altstr);

		update_post_meta( $id, '_wp_attachment_image_alt', ucfirst($altstr) );
	}

	// add formatted title
	if ( isset( $options['text_title'] ) && $options['text_title'] ) {
		$titlestr = $options['text_title'];
		$titlestr = add_features_connector($titlestr, $homefeatures_reply,
			$features_connector);
		$titlestr = str_replace("{{HomeScenes}}", $homescences_reply, $titlestr);
		$titlestr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $titlestr);
		$title = ucfirst($titlestr);
	}

	$uploaded_post['post_title'] = $title;
	$uploaded_post['post_name'] = $title;

	// add formatted description meta field

	if ( isset( $options['text_description'] ) && $options['text_description'] ) {
		$descstr = $options['text_description'];
		$descstr = add_features_connector($descstr, $homefeatures_reply,
			$features_connector);
		$descstr = str_replace("{{HomeScenes}}", $homescences_reply, $descstr);
		$descstr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $descstr);
		$uploaded_post['post_content'] = ucfirst($descstr);
	}

	// add formatted caption meta field

	if ( isset( $options['text_caption'] ) && $options['text_caption'] ) {
		$capstr = $options['text_caption'];
		$capstr = add_features_connector($capstr, $homefeatures_reply,
			$features_connector);
		$capstr = str_replace("{{HomeScenes}}", $homescences_reply,$capstr);
		$capstr = str_replace("{{HomeFeatures}}", $homefeatures_reply,$capstr);
		$uploaded_post['post_excerpt'] = ucfirst($capstr);
	}

	if ( isset( $options['text_filename'] ) && $options['text_filename'] ) {
		$file_str = $options['text_filename'];
		$file_str = add_features_connector($file_str, $homefeatures_reply,
			$features_connector);
		$file_str = str_replace("{{HomeScenes}}", $homescences_reply, $file_str);
		$file_str = str_replace("{{HomeFeatures}}", $homefeatures_reply, $file_str);

		$actual_filename = rename_filename($id, $file_str);
		save_handled_post_id($id);

		$metadata = wp_generate_attachment_metadata($id, $actual_filename['local']);
		$result = wp_update_attachment_metadata($id, $metadata);
	}

	wp_update_post( $uploaded_post );
}

function get_reduced_tmp_file( $id ) {
	$fullsize_path = get_attached_file( $id );
	$path_info = pathinfo( $fullsize_path );
	$filename = basename( $fullsize_path );

	$image = wp_get_image_editor( $fullsize_path );

	if ( ! is_wp_error( $image ) ) {
		$size = $image->get_size();
		
		if ($size["width"] > $size["height"])
			$image->resize( REDUCED_IMAGE_SIZE, NULL, false );
		else
			$image->resize( NULL, REDUCED_IMAGE_SIZE, false );
	
		$filename = "small_" . $filename;
		$fullsize_path = path_join($path_info['dirname'], $filename);

		$image->save( $fullsize_path );
	}
	
	$new_url = path_join( wp_upload_dir()['url'], $filename );

	return array(
		"local" => $fullsize_path,
		"url"   => $new_url
	);
}

function remove_file( $path ) {
	if( file_exists( $path ) ) {
		unlink( $path );
	}
}

function rename_filename($post_id, $post_title) {
	$post = get_post($post_id);
	$file = get_attached_file($post_id);
	$path = pathinfo($file);

	$new_filename = sanitize_file_name($post_title) . "." . $path['extension'];
	$new_filename = wp_unique_filename($path['dirname'], $new_filename);

	$newfile = path_join($path['dirname'], $new_filename);
	$newurl = path_join(wp_upload_dir()['url'], $new_filename);

	rename($file, $newfile);
	update_attached_file($post_id, $newfile);

	return array(
		"local" => $newfile,
		"url" => $newurl,
    "name" => $new_filename
	);
}

function add_features_connector($placeholder, $features, $connector) {
	if (can_add_features_connector($placeholder, $features)) {
		$placeholder = str_replace("{{FeaturesConnector}}", $connector, $placeholder);
	} else {
		$placeholder = str_replace("{{FeaturesConnector}}", '', $placeholder);
	}

	return $placeholder;
}

function can_add_features_connector($placeholder, $features) {
	return strpos($placeholder, '{{HomeFeatures}}') !== false
		&& !empty($features);
}

function restbapi($endpoint, $model, $imageurl) {
	$url = 'http://api.restb.ai/' . $endpoint;
	$options = get_option('REautotag_options');
	$clientkey = $options[OPTION_CLIENT_KEY];
	$data = array(
		'client_key' => $clientkey,
		'model_id' => $model,
		'image_url' => $imageurl
	);

	return call_and_retry_restb_api($url, $data);
}

function call_and_retry_restb_api($url, $data) {
	if (is_localhost()) {
		$response = call_with_base64($url, $data);
	} else {
		$response = CallAPI('GET', $url, $data);
		if (invalid_image($response))
			$response = call_with_base64($url, $data);
	}

	return $response;
}

function is_localhost() {
	$LOCALHOSTS = array('localhost', '127.0.0.1', '127.0.1.1', '::1');
	$url = get_site_url();
	$parse = parse_url($url);

	return in_array($parse['host'], $LOCALHOSTS);
}

function call_with_base64($url, $data) {
	$data['image_base64'] = image_base64($data['image_url']);
	unset($data['image_url']);

	return CallAPI('POST', $url, $data);
}

function invalid_image($response) {
	if ($response->error == 'true')
		return $response->error_id == '001';
	else
		return false;
}

function image_base64($image_url) {
	$image_content = file_get_contents($image_url);
	$image_base64 = base64_encode($image_content);

	return $image_base64;
}

function CallAPI($method, $url, $data = false)
{
    $curl = curl_init();

    switch ($method)
    {
        case "POST":
            curl_setopt($curl, CURLOPT_POST, 1);

            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_PUT, 1);
            break;
        default:
            if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
    }

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    // Disable SSL check
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

    $result = curl_exec($curl);

    if($result === false) {
        $result = (object) array(
            "code"    => curl_errno($curl),
            "message" => curl_error($curl)
        );
    } else {
        $result = json_decode($result);
    }

    curl_close($curl);

    return $result;
}

function handle_restb_errors($response) {
	switch ( $response->error_id ) {
		case "004":
			$response = handle_request_limit_reached($response);
			break;
		case "002":
			$response = handle_unkown_client($response);
			break;
	}
	
	add_restb_error($response->error_id, $response->message);
}

function handle_request_limit_reached($response) {
	if (can_upgrade_key())
		$response->error_id .= "_upgradable";

	// Make sure that "upgrade" button is displayed
	set_if_upgraded_key();

	return $response;
}

function handle_unkown_client($response) {
	remove_client_key();

	return $response;
}

function add_restb_error($code, $message) {
	$restb_errors = get_restb_option(OPTION_API_ERRORS);
	$restb_errors[$code] = $message;
	update_restb_option(OPTION_API_ERRORS, $restb_errors);
}
