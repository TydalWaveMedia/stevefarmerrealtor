<?php
/*
Plugin Name: Restb.ai Auto Tag
Plugin URI: http://www.restb.ai
Description: Automatically extract the information of a realestate pictures!
Version: Beta
Author: Restb.ai
Author URI: http://www.restb.ai
*/

register_activation_hook( __FILE__, 'REautotag_add_defaults' );
register_uninstall_hook( __FILE__, 'REautotag_delete_plugin_options' );
add_action( 'admin_menu', 'REautotag_add_options_page' );
add_action('admin_init', 'REautotag_init' );
add_action( 'add_attachment', 'REautotag_update_media_info' );
add_action( 'admin_notices', 'REautotag_dashboard_notice' );

function REautotag_dashboard_notice() {
	$options     = get_option( 'REautotag_options' );
	$client_key = $options['client_key'];
	if (!$client_key){
    ?>
	    <div class="notice notice-warning is-dismissible">
	        <p><?php _e( 'Restb.ai client key is missing. Please enter your valid client key in the plugin settings field. If you dont have an client key you can get one by signing up for a free account at restb.ai!', 'realestate-auto-tag' ); ?></p>
	    </div>
    <?php
	}

}

 
 
/* Delete options when plugin deactivated AND deleted. */
function REautotag_delete_plugin_options() {
	delete_option( 'REautotag_options' );
}

/* Define default settings. */
function REautotag_add_defaults() {
	$tmp = get_option( 'REautotag_options' );
	if ( ( $tmp['chk_default_options_db'] == '1' ) || ( ! is_array( $tmp ) ) ) {
		delete_option( 'REautotag_options' );
		$arr = array( "client_key"        => "",
					  "text_title"             => "{{HomeScenes}} with {{HomeFeatures}}",
					  "text_alt"             => "{{HomeScenes}} with {{HomeFeatures}}",
					  "text_description"         => "{{HomeScenes}} with {{HomeFeatures}}",
					  "text_caption"        => "{{HomeScenes}} - {{HomeFeatures}}",
					  "and_conjunction"        => "&",
		);
		update_option( 'REautotag_options', $arr );
	}
}

/* Init plugin options. */
function REautotag_init(){
    register_setting( 'REautotag_plugin_options', 'REautotag_options' );
}

/* Add menu page. */
function REautotag_add_options_page() {
	add_options_page( 'RealEstate Auto Tag Options Page', 'RealEstate Auto Tag', 'manage_options', __FILE__, 'REautotag_render_form' );
}

/* Render Plugin options page. */
function REautotag_render_form() {
	?>
	<div class="wrap">
		<h2><?php _e( 'RealEstate Auto Tag', 'realestate-auto-tag' ); ?></h2>

		<form method="post" action="options.php">
			<?php settings_fields( 'REautotag_plugin_options' ); ?>
			<?php $options = get_option( 'REautotag_options' ); ?>

			<table class="form-table">
				<tr valign="top">
					<th scope="row"><?php _e( 'Authorize the Restb.ai Plugin', 'realestate-auto-tag' ); ?></th>
					<td>
						<p>Thank you for installing RealEstate Auto Tag for wordpress. Please enter your client key in the field below. If you dont have a client key you can get one by signing up for a free account at restb.ai </p>
						<label><strong><?php _e( 'Client key', 'realestate-auto-tag' ); ?> </strong><input name="REautotag_options[client_key]" type="text" size="50" value="<?=$options['client_key']?>"/> </label><br>
					</td>
				
				</tr>
				<tr valign="top">
					<th scope="row"><?php _e( 'Text replacing options', 'realestate-auto-tag' ); ?></th>
					<td>
						<label><?php _e( 'Add Image information to \'Title\' (Keep it empty for default Title)', 'realestate-auto-tag' ); ?> <input name="REautotag_options[text_title]" type="text" size="100" value="<?=$options['text_title']?>"/> </label><br>
						<label><?php _e( 'Add Image information to \'Alternative Text\' attribute', 'realestate-auto-tag' ); ?> <input name="REautotag_options[text_alt]" type="text" size="100" value="<?=$options['text_alt']?>"/> </label><br>
						<label><?php _e( 'Add Image information to \'Caption\' attribute', 'realestate-auto-tag' ); ?> <input name="REautotag_options[text_caption]" type="text" size="100" value="<?=$options['text_caption']?>"/> </label><br>
						<label><?php _e( 'Add Image information to \'Description\' attribute', 'realestate-auto-tag' ); ?> <input name="REautotag_options[text_description]" type="text" size="100" value="<?=$options['text_description']?>"/> </label><br>
					</td>
				
				</tr>
				<tr>
					<td colspan="2">
						<div></div>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php _e( 'Misc. Options', 'realestate-auto-tag' ); ?></th>
					<td>
						<label><?php _e( 'Replace last comma with a connector conjunction (And / &) ', 'realestate-auto-tag' ); ?> <input name="REautotag_options[and_conjunction]" type="text" size="100" value="<?=$options['and_conjunction']?>"/> </label><br>
					</td>	
				</tr>
				<tr valign="top" style="border-top:#dddddd 1px solid;">
					<th scope="row"><?php _e( 'Database Options', 'realestate-auto-tag' ); ?></th>
					<td>
						<label><input name="REautotag_options[chk_default_options_db]" type="checkbox" value="1" <?php if ( isset( $options['chk_default_options_db'] ) ) {
								checked( '1', $options['chk_default_options_db'] );
							} ?> /> <?php _e( 'Restore defaults upon plugin deactivation/reactivation', 'realestate-auto-tag' ); ?></label>
						<p class="description"><?php _e( 'Only check this if you want to reset plugin settings upon Plugin reactivation', 'realestate-auto-tag' ); ?></p>
					</td>
				</tr>
			</table>
			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e( 'Save Changes', 'realestate-auto-tag' ); ?>" />
			</p>
		</form>

		 

		
	</div>
<?php
}
/* Display the Settings link on Plugins page. */
function REautotag_settings_link( $links ) {
    $url = get_admin_url() . 'options-general.php?page=realestate-auto-tag.php';
    $settings_link = '<a href="' . $url . '">' . __('Settings', 'textdomain') . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}
 
function REautotag_after_setup_theme() {
     add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'REautotag_settings_link');
}


add_action ('after_setup_theme', 'REautotag_after_setup_theme');





function REautotag_update_media_info( $id ) {

	$options     = get_option( 'REautotag_options' );
	$cap_options = $options['rdo_cap_options'];

	$uploaded_post_id = get_post( $id );
	$title            = $uploaded_post_id->post_title;
	$url_image = wp_get_attachment_url( $id );
	//$restb_reply = restbapi($url_image);

	$jsonHomeScenes = restbapi('classify','real_estate_global',$url_image);
	$jsonHomeFeatures = restbapi('segmentation','re_features',$url_image);

	$arrHomeScenes = json_decode($jsonHomeScenes);
	$arrHomeFeatures = json_decode($jsonHomeFeatures);

	foreach($arrHomeScenes->response->probabilities as $probabilities)
	{

		if ($probabilities[0][0]=='non_related'){
			return ;
		}else{
			$scene = str_replace("_", " ", $probabilities[0][0]);
			$homescences_reply = $scene;			
		}
	    //foreach($probabilities as $homescene)
	    //{
	    	//$homescences_reply .=  $homescene[0];

	    //}
	}

	foreach($arrHomeFeatures->response->objects as $objects)
	{
		$feature = str_replace("_", " ", $objects[0]);
		if (count($duplicated_features)==0){
			$homefeatures_reply .= $feature.', ';
		}elseif (!in_array($objects[0], $duplicated_features)) {
    		$homefeatures_reply .= $feature.', ';
  		}
  	    $duplicated_features[] = $objects[0];
  	    		
  	    		
	}
	//Remove last comma string
	$homefeatures_reply = rtrim($homefeatures_reply, ', ');
	//Replace last comma with And conjuntion
	$andreplacement = ' '.$options['and_conjunction'].'\1';
	$homefeatures_reply = preg_replace('/,([^,]*)$/', $andreplacement, $homefeatures_reply);
	//$restb_reply = $jsonHomeScenes.$jsonHomeFeatures;





	// start updating the post
	$uploaded_post               = array();
	$uploaded_post['ID']         = $id;
	
	// add formatted alt 
	if ( isset( $options['text_alt'] ) && $options['text_alt'] ) {
		$altstr = $options['text_alt'];
		$altstr = str_replace("{{HomeScenes}}", $homescences_reply, $altstr);
		$altstr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $altstr);

		update_post_meta( $id, '_wp_attachment_image_alt', ucfirst($altstr) );
	}

	// add formatted title
	if ( isset( $options['text_title'] ) && $options['text_title'] ) {
		$titlestr = $options['text_title'];
		$titlestr = str_replace("{{HomeScenes}}", $homescences_reply, $titlestr);
		$titlestr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $titlestr);
		$uploaded_post['post_title'] = ucfirst($titlestr);
	}else{
		$uploaded_post['post_title'] = $title;
	}



	// add formatted description meta field

	if ( isset( $options['text_description'] ) && $options['text_description'] ) {
		$descstr = $options['text_description'];
		$descstr = str_replace("{{HomeScenes}}", $homescences_reply, $descstr);
		$descstr = str_replace("{{HomeFeatures}}", $homefeatures_reply, $descstr);
		$uploaded_post['post_content'] = ucfirst($descstr);
	}

	// add formatted caption meta field

	if ( isset( $options['text_caption'] ) && $options['text_caption'] ) {
		$capstr = $options['text_caption'];
		$capstr = str_replace("{{HomeScenes}}", $homescences_reply,$capstr);
		$capstr = str_replace("{{HomeFeatures}}", $homefeatures_reply,$capstr);
		$uploaded_post['post_excerpt'] = ucfirst($capstr);
	}

	wp_update_post( $uploaded_post );
} 


function restbapi($endpoint,$model,$imageurl){

	$options   = get_option( 'REautotag_options' );
	$clientkey = $options['client_key'];
	$service_url = 'http://api.restb.ai/'.$endpoint.'?client_key='.$clientkey.'&model_id='.$model.'&image_url='.$imageurl;
	return file_get_contents($service_url);

}